/*
Pose Estimator program for a tricycle with front wheel steering.
Pose of platform = pose of center of rear axis.
Initial pose = (0,0,0)
Given steering angle, angular velocity, wheelbase, track,
wheel radius, encoder ticks and time, position and orientation
of the mobile platform is estimated.
Right-hand coordinate system is used.

Author Name: Prasanth.S.S
Email: prasuchit@gmail.com
Do not alter or use for commercial purposes without prior permission
from the author.
*/
#include <tuple>
#include <iostream>
#include <conio.h>
#define _USE_MATH_DEFINES
#include<math.h>
#include <boost/numeric/odeint.hpp>
using namespace std;
using namespace boost::numeric::odeint;
typedef std::vector < double > state_type;
typedef dense_output_runge_kutta<controlled_runge_kutta<runge_kutta_dopri5<state_type> > > stepper_type;
double t_in_sec = 0, h_a_d, x_d, y_d, head, xpose, ypose,temp;
int enc_ticks = 0, ang_vel = 0;
float st_ang = 0; char repeat = 'y';
class tricycle_params {
public:
	tricycle_params();
	int time = 0;	//seconds
	int encoder_ticks = 0;	//ticks
	int ang_vel = 0;	//rad/sec
	float x_platform = 0;	//meters
	state_type x_init{ 0 };	//meters
	float y_platform = 0;	//meters
	state_type y_init{ 0 };	//meters
	float heading_angle;	//radians
	state_type h_ang_init{ 0 };	//Initial value for integration
	double t_init;	//starting time
	float steering_angle = 0;	//radians
	double front_wheel_radius = 0.2;	//meters
	double wheelbase = 1;	//meters
	double track = 0.75;	//meters
	double encoder_resolution = 512;	//ticks per revolution
	// Declaring tuple
	tuple <float, float, float> est_pose{};
	tuple <double, double , double > estimated_pose{ xpose, ypose, head };
	tuple <float, float, float> estimate(int, float, int, int);
	~tricycle_params();
};

int main(int argc, char ** argv);
